package br.edu.ifsp.graphql.model;

public enum Episode {
    NEWHOPE, EMPIRE, JEDI
}
