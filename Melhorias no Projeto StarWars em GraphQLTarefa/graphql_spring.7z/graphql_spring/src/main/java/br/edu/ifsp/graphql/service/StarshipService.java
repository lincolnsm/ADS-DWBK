package br.edu.ifsp.graphql.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.edu.ifsp.graphql.model.Starship;
import br.edu.ifsp.graphql.repository.StarshipRepository;

@Service
public class StarshipService {

    @Autowired
    private StarshipRepository starshipRepository;

    public List<Starship> findAllStarships() {
        return starshipRepository.findAllStarships();
    }

    public Starship createStarship(Starship starship) {
        starshipRepository.saveStarship(starship);
        return starship;
    }
}