package br.edu.ifsp.graphql.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.edu.ifsp.graphql.model.Droid;
import br.edu.ifsp.graphql.model.Episode;
import br.edu.ifsp.graphql.repository.DroidRepository;

@Service
public class DroidService {

    @Autowired
    private DroidRepository droidRepository;

    public Droid getHero(Episode episode) {
        // Lógica para determinar o herói com base no episódio
        return droidRepository.findDroidById("2001").orElse(null);
    }
    
    public Optional<Droid> findDroidById(String id) {
        return droidRepository.findDroidById(id);
    }

    public Droid createDroid(Droid droid) {
        droidRepository.saveDroid(droid);
        return droid;
    }
}