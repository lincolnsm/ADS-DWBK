package br.edu.ifsp.graphql.repository;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.stereotype.Repository;

import br.edu.ifsp.graphql.model.Droid;
import br.edu.ifsp.graphql.model.Episode;

@Repository
public class DroidRepository {

    private List<Droid> droids = new ArrayList<>(List.of(
        new Droid("2000", "C-3PO", List.of(Episode.NEWHOPE, Episode.EMPIRE, Episode.JEDI), new ArrayList<>(), "Protocol"),
        new Droid("2001", "R2-D2", List.of(Episode.NEWHOPE, Episode.EMPIRE, Episode.JEDI), new ArrayList<>(), "Astromech")
    ));

    public List<Droid> findAllDroids() {
        return droids;
    }

    public Optional<Droid> findDroidById(String id) {
        return droids.stream().filter(d -> d.getId().equals(id)).findFirst();
    }
    
    public void saveDroid(Droid droid) {
        droids.add(droid);
    }

    public void updateDroid(Droid droid) {
        droids = droids.stream()
            .map(d -> d.getId().equals(droid.getId()) ? droid : d)
            .collect(Collectors.toList());
    }

    public void deleteDroid(String id) {
        droids.removeIf(d -> d.getId().equals(id));
    }
}