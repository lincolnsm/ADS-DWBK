package br.edu.ifsp.graphql.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.graphql.data.method.annotation.Argument;
import org.springframework.graphql.data.method.annotation.MutationMapping;
import org.springframework.graphql.data.method.annotation.QueryMapping;
import org.springframework.stereotype.Controller;

import br.edu.ifsp.graphql.model.Character;
import br.edu.ifsp.graphql.model.Droid;
import br.edu.ifsp.graphql.model.Episode;
import br.edu.ifsp.graphql.model.Human;
import br.edu.ifsp.graphql.model.Review;
import br.edu.ifsp.graphql.model.ReviewInput;
import br.edu.ifsp.graphql.model.Starship;
import br.edu.ifsp.graphql.service.CharacterService;
import br.edu.ifsp.graphql.service.DroidService;
import br.edu.ifsp.graphql.service.HumanService;
import br.edu.ifsp.graphql.service.ReviewService;
import br.edu.ifsp.graphql.service.StarshipService;

@Controller
public class StarWarController {

    @Autowired
    private DroidService droidService;
    
    @Autowired
    private HumanService humanService;

    @Autowired
    private StarshipService starshipService;

    @Autowired
    private ReviewService reviewService;

    @Autowired
    private CharacterService characterService;

    @QueryMapping
    public Character hero(@Argument Episode episode) {
        return droidService.getHero(episode);
    }

    @QueryMapping
    public Droid droid(@Argument String id) {
        Optional<Droid> droid = droidService.findDroidById(id);
        return droid.orElse(null);
    }
    
    @QueryMapping
    public List<Object> search(@Argument String text) {
        return characterService.search(text);
    }

    @QueryMapping
    public List<Human> humans() {
        return humanService.findAllHumans();
    }

    @QueryMapping
    public List<Starship> starships() {
        return starshipService.findAllStarships();
    }

    @QueryMapping
    public Character character(@Argument String id) {
        Optional<Character> character = characterService.findCharacterById(id);
        return character.orElse(null);
    }

    @MutationMapping
    public Review createReview(@Argument Episode episode, @Argument ReviewInput review) {
        return reviewService.createReview(review);
    }
    
    @MutationMapping
    public Human createHuman(@Argument String id, @Argument String name, @Argument Double height) {
        Human human = new Human(id, name, List.of(), List.of(), height);
        return humanService.createHuman(human);
    }

    @MutationMapping
    public Droid createDroid(@Argument String id, @Argument String name, @Argument String primaryFunction) {
        Droid droid = new Droid(id, name, List.of(), List.of(), primaryFunction);
        return droidService.createDroid(droid);
    }

    @MutationMapping
    public Starship createStarship(@Argument int id, @Argument String name, @Argument Double length) {
        Starship starship = new Starship(id, name, length);
        return starshipService.createStarship(starship);
    }

    @MutationMapping
    public Character addFriend(@Argument String characterId, @Argument String friendId) {
        return characterService.addFriend(characterId, friendId);
    }

}