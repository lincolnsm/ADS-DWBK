package br.edu.ifsp.graphql.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.edu.ifsp.graphql.model.Human;
import br.edu.ifsp.graphql.repository.HumanRepository;

@Service
public class HumanService {
    
    @Autowired
    private HumanRepository humanRepository;

    public List<Human> findAllHumans() {
        return humanRepository.findAllHumans();
    }

    public Human createHuman(Human human) {
        humanRepository.saveHuman(human);
        return human;
    }
}