package br.edu.ifsp.graphql.repository;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.stereotype.Repository;

import br.edu.ifsp.graphql.model.Starship;

@Repository
public class StarshipRepository {

    private List<Starship> starships = new ArrayList<>(List.of(
        new Starship(3000, "Millenium Falcon", 34.37),
        new Starship(3001, "X-Wing", 12.5)
    ));

    public List<Starship> findAllStarships() {
        return starships;
    }

    public Optional<Starship> findStarshipById(int id) {
        return starships.stream().filter(s -> s.getId() == id).findFirst();
    }

    public void saveStarship(Starship starship) {
        starships.add(starship);
    }

    public void updateStarship(Starship starship) {
        starships = starships.stream()
            .map(s -> s.getId() == starship.getId() ? starship : s)
            .collect(Collectors.toList());
    }

    public void deleteStarship(int id) {
        starships.removeIf(s -> s.getId() == id);
    }
}