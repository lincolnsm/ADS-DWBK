package br.edu.ifsp.graphql.repository;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.springframework.stereotype.Repository;

import br.edu.ifsp.graphql.model.Episode;
import br.edu.ifsp.graphql.model.Human;

@Repository
public class HumanRepository {

    private List<Human> humans = new ArrayList<>(List.of(
        new Human("1000", "Luke Skywalker", List.of(Episode.NEWHOPE, Episode.EMPIRE, Episode.JEDI), new ArrayList<>(), 1.72),
        new Human("1001", "Darth Vader", List.of(Episode.NEWHOPE, Episode.EMPIRE, Episode.JEDI), new ArrayList<>(), 2.02)
    ));

    public List<Human> findAllHumans() {
        return humans;
    }

    public Optional<Human> findHumanById(String id) {
        return humans.stream().filter(h -> h.getId().equals(id)).findFirst();
    }

    public void saveHuman(Human human) {
        humans.add(human);
    }

    public void updateHuman(Human human) {
        humans = humans.stream()
            .map(h -> h.getId().equals(human.getId()) ? human : h)
            .collect(Collectors.toList());
    }

    public void deleteHuman(String id) {
        humans.removeIf(h -> h.getId().equals(id));
    }
}